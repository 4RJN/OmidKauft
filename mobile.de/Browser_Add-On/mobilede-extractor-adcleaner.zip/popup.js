
async function sendToActiveTab(message) {
  const [tab] = await chrome.tabs.query({active: true, currentWindow: true});
  if (!tab?.id) return;
  return chrome.tabs.sendMessage(tab.id, message);
}

document.getElementById('run').addEventListener('click', async () => {
  await sendToActiveTab({type: 'RUN_EXTRACTOR'});
  window.close();
});

const adclean = document.getElementById('adclean');

// init state
(async () => {
  const resp = await sendToActiveTab({type: 'GET_STATE'});
  if (resp && typeof resp.adCleaner !== 'undefined') {
    adclean.checked = !!resp.adCleaner;
  }
})();

adclean.addEventListener('change', async (e) => {
  await sendToActiveTab({type: 'SET_AD_CLEANER', enabled: e.target.checked});
});
